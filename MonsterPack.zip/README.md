# Monster Resource Pack

마인크래프트 서버의 커스텀 몬스터와 장비용 리소스팩입니다.

## 구조

- `assets/monstercraft/items/` — 아이템 모델 정의
- `assets/monstercraft/models/monsters/` — 몬스터 모델 원본/문서
- `assets/monstercraft/models/item/` — 게임에서 사용하는 모델
- `assets/monstercraft/textures/monsters/` — 몬스터 텍스처
- `assets/monstercraft/textures/item/` — 장비·아이템 텍스처

## 첫 번째 몬스터: 이끼 고블린 정찰병

작은 초록 체형, 뾰족귀, 갈색 가죽 장비를 사용합니다. 서버에서는 전용 `item_model`을 머리 장비에 적용해 바닐라 몬스터와 별개로 표시합니다.

> 이 저장소에는 비밀번호, 서버 주소, `server.properties` 같은 서버 설정 파일을 올리지 않습니다.
