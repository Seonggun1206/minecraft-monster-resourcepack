# Monster model sources

몬스터별 원본 모델은 이 폴더에서 관리합니다. 파일 이름은 `monster-id`를 사용합니다.

예: `goblin_scout.bbmodel`
